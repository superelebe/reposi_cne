
<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Noticia Index
    </h1>

    <div>
            <?php $__currentLoopData = $noticia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div>
                <div>
                    <div>
                        <?php echo e($noticias->imagen); ?>

                    </div>
                </div>
                <div><?php echo e($noticias->titulo); ?></div>
                <div><?php echo e($noticias->subtitulo); ?></div>
                <div><?php echo e($noticias->cuerpo); ?></div>
                <div><a href="/noticia/<?php echo e($noticias->id); ?>">Ver mas</a></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
    <?php echo e($noticia->links()); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>