<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Noticia Index
    </h1>
    <form class = 'col s3' method = 'get' action = '<?php echo url("article"); ?>/create'>
        <button class = 'btn btn-primary' type = 'submit'>Crear Nueva Noticia</button>
    </form>
    <br>
    <br>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>titulo</th>
            <th>subtitulo</th>
            <th>cuerpo</th>
            <th>imagen</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo $article->titulo; ?></td>
                <td><?php echo $article->subtitulo; ?></td>
                <td><?php echo $article->imagen; ?></td>
                <td><?php echo $article->cuerpo; ?></td>
                <td>
                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/article/<?php echo $article->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                    <a href = '#' class = 'viewEdit btn btn-primary btn-xs' data-link = '/article/<?php echo $article->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/article/<?php echo $article->id; ?>'><i class = 'material-icons'>info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <?php echo $articles->render(); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>