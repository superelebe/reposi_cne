<?php $__env->startSection('content'); ?>



    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-cursos.png')); ?>" alt="">
            </div>
        </div>
    </div>
<div class="empresas">
    <div class="ocho80">
        <table width="882" style="margin:45px 0 -25px;">
            <thead>
                <tr>
                    <td>CURSO</td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td valign="top">
                        <div class="row row-centered">
                            <div class='col-md-12 col-centered alineado_izq'>
                                <div id="nombre"><?php echo $cursos->title; ?></div>
                                <div id="subarea"><?php echo $cursos->start->format('d \- F \- Y'); ?></div>
                                <div id="subarea">Publicado: <?php echo e($cursos->created_at->diffForHumans()); ?></div>
                            </div>
                        </div>
                        <div id="direccion" class='descripcion_bolsa'>
                            <p>Horarios: <?php echo $cursos->horarios; ?></p>
                            <p>Inversion: <?php echo $cursos->inversion; ?></p>
                            <?php echo $cursos->descripcion; ?>

                            <p>Lugar: <?php echo e($cursos->lugar); ?></p>
                        </div>
                    </td>
                    <td valign="top" bgcolor="#455560">
                        <div class="col-md-12 col-centered">
                            <img class='largo_imagenes_cursos' src="<?php echo e($cursos->pdf); ?>" alt="">
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>   
    </div> 
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>