<?php $__env->startSection('content'); ?>



    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-vacante.png')); ?>" alt="">
            </div>
        </div>
    </div>



<section class="content">

    <div class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <div class="col-xs-12 col-centered">        
                <form  method = 'get' action = '<?php echo url("bolsa_trabajo"); ?>/create'>
                      <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nuevo Trabajo</span></button>
                </form>
                
            </div>

            <div id="paginacion"><?php echo $trabajos->render(); ?> </div>
              <div class="col-md-12 col-centered">
                <div class="table-responsive">
                    <table class='table table-striped' cellpadding="10">
                        <thead>
                            <tr>
                                <td>TITULO</td>
                                <td>EMPRESA</td>
                                <td>DESCRIPCIÓN</td>
                                <td>SUELDO</td>
                                <td>IMAGEN</td>
                                <td>BORRAR</td>
                                <td>EDITAR</td>
                                <td>INFO</td>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                <td><?php echo $trabajo->titulo; ?></td>
                                <td><?php echo $trabajo->empresa; ?></td>
                                <td><?php echo e(substr(strip_tags($trabajo->descripcion),0,50)); ?><?php echo e(strlen(strip_tags($trabajo->descripcion)) > 50 ? "...":""); ?></td>
                                <td><?php echo $trabajo->sueldo; ?></td>
                                <td><img class='largo_imagenes' src="<?php echo url($trabajo->imagen); ?>" alt=""></td>
                                <td>
                                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/trabajo/<?php echo $trabajo->id; ?>/deleteMsg" ><i class = 'material-icons'>Borrar</i></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('bolsa_trabajo.edit', $trabajo->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/trabajo/<?php echo $trabajo->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                                </td>
                                <td>
                                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/trabajo/<?php echo $trabajo->id; ?>'><i class = 'material-icons'>info</i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>    
                </div>    
            </div>
            <?php echo $trabajos->render(); ?>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>