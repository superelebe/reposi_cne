<?php $__env->startSection('content'); ?>
<div id="servicios">
	<div class="ocho80">
    	<div id="contenedorserv" class="limpiar">
			<div class="tiraservicio limpiar">
				<div class="icoservicio"> </div>
				<div class="icoservicio">
		        	<img src="img/serv-1.png" alt="servicios cnec" />
	                <h5>REPORTES DE <span>LICITACIONES</span> PÚBLICAS (SIVA)</h5>
	                <span class="vermas azulmedio"><a href="<?php echo e(url('/licitaciones')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-2.png" alt="servicios cnec" />
	                <h5>MONITOREO <span>LEGISLATIVO</span></h5>
	                <span class="vermas azulclaro"><a href="<?php echo e(url('/monitoreo')); ?>">VER MÁS</a></span>
		        </div>
			</div>
		    
		    <div class="tiraservicio limpiar">
				<div class="icoservicio">
		        	<img src="img/serv-3.png" alt="servicios cnec" />
	                <h5>METODOLOGÍA PARA EL <span>CÁLCULO DE FACTORES</span> ECONÓMICOS <small>(ARANCELES)</small></h5>
	                <span class="vermas azuloscuro"><a href="<?php echo e(url('/calculo')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-4.png" alt="servicios cnec" />
	                <h5>GUÍA PARA LA <br /><span>SELECCIÓN DE</span><br /> CONSULTORES</h5>
	                <span class="vermas azulmedio"><a href="<?php echo e(url('/consultores')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-5.png" alt="servicios cnec" />
	                <h5>CAPACITACIÓN, <span>ACTUALIZACIÓN Y</span> ADIESTRAMIENTO</h5>
	                <span class="vermas azulclaro"><a href="<?php echo e(url('/adiestramiento')); ?>">VER MÁS</a></span>
		        </div>
			</div>
		    
		    <div class="tiraservicio limpiar">
				<div class="icoservicio">
		        	<img src="img/serv-6.png" alt="servicios cnec" />
	                <h5>DIRECTORIO DE <span>EMPRESAS AFILIADAS Y</span> CERTIFICADAS</h5>
	                <span class="vermas azuloscuro"><a href="<?php echo e(url('/afiliadas')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-7.png" alt="servicios cnec" />
	                <h5>PRECIÓS PREFERENCIALES <br /><span>EN CURSOS, TALLERES O</span> CAPACITACIONES.</h5>
	                <span class="vermas azulmedio"><a href="<?php echo e(url('/capacitaciones')); ?>">VER MÁS</a></span>
	                <span class="vermas azulmedio"><a href="<?php echo e(url('/capacitacion')); ?>">VER MÁS</a></span>

		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-8.png" alt="servicios cnec" />
	                <h5>PUBLICACIONES <br /><span>CNEC –FIDOC</span></h5>
	                <span class="vermas azulclaro"><a href="<?php echo e(url('/publicaciones')); ?>">VER MÁS</a></span>
		        </div>
			</div>
		    
		    <div class="tiraservicio limpiar" style="margin-bottom:0;">
				<div class="icoservicio">
		        	<img src="img/serv-9.png" alt="servicios cnec" />
	                <h5>PARTICIPACIÓN EN <span>COMISIONES MIXTAS</span></h5>
	                <span class="vermas azuloscuro"><a href="<?php echo e(url('/comisiones')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-10.png" alt="servicios cnec" />
	                <h5>REVISTAS CONSULTORAS <span>"INDUSTRIA DEL</span> CONOCIMIENTO"</h5>
	                <span class="vermas azulmedio"><a href="<?php echo e(url('/conocimiento')); ?>">VER MÁS</a></span>
		        </div>
				<div class="icoservicio">
		        	<img src="img/serv-11.png" alt="servicios cnec" />
	                <h5>SERVICIOS DEL<br /><span> SIEM</span></h5>
	                <span class="vermas azulclaro"><a href="<?php echo e(url('/siem')); ?>">VER MÁS</a></span>
		        </div>
			</div>
           
        </div><!--ontenedor servicios-->
    </div>
</div>
<!--termina div del servicios-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>