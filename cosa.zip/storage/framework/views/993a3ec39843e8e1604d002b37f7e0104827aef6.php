<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Show event
    </h1>
    <table class = 'table table-bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>title : </i></b>
                </td>
                <td><?php echo $event->title; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>start : </i></b>
                </td>
                <td><?php echo $event->start->format('d \- F \- Y'); ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>end : </i></b>
                </td>
                <td><?php echo $event->end->format('d \- F \- Y'); ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>imagen : </i></b>
                </td>
                <td> <img src="<?php echo $event->imagen; ?>" alt=""></td>
            </tr>
            <tr>
                <td>
                    <b><i>color : </i></b>
                </td>
                <td><?php echo $event->color; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>subtitulo : </i></b>
                </td>
                <td><?php echo $event->subtitulo; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>descripcion : </i></b>
                </td>
                <td><?php echo $event->descripcion; ?></td>
            </tr>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>