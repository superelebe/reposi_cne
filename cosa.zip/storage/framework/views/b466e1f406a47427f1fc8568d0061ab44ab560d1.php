<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Capacitaciones Index
    </h1>
    <form class = 'col s3' method = 'get' action = '<?php echo url("curso"); ?>/create'>
        <button class = 'btn btn-primary' type = 'submit'>Crear Nuevo Capacitacion</button>
    </form>
    <br>
    <br>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>titulo</th>
            <th>empresa</th>
            <th>sueldo</th>
            <th>descripcion</th>
            <th>imagen</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $capacitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo $capa->titulo; ?></td>
                <td><?php echo $capa->start; ?></td>
                <td><?php echo $capa->end; ?></td>
                <td><?php echo $capa->url; ?></td>
                <td><?php echo $capa->pdf; ?></td>
                <td>
                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/trabajo/<?php echo $capa->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                    <a href="<?php echo e(route('curso.edit', $capa->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/trabajo/<?php echo $capa->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/trabajo/<?php echo $capa->id; ?>'><i class = 'material-icons'>info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <?php echo $capacitaciones->render(); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>