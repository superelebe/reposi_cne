<?php $__env->startSection('content'); ?>

    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-vacante.png')); ?>" alt="">
            </div>
        </div>
    </div>
<div class="empresas">
    <div class="ocho80">
        <table style="margin:45px 0 -25px;" width="882">
                        <thead>
                            <tr>
                                <td>VACANTE</td>
                                <td>POSTULARME</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="row row-centered">
                                        <div class="col-md-4 col-centered">
                                            <img class='largo_imagenes' src="<?php echo e($vacante->imagen); ?>" alt="">
                                        </div>
                                        <div class='col-md-8 col-centered alineado_izq'>
                                            <div id="nombre"><?php echo e($vacante->titulo); ?></div>
                                            <div id="subarea"><?php echo e($vacante->empresa); ?></div>
                                            <div id="subarea">Publicado: <?php echo e($vacante->created_at->diffForHumans()); ?></div>
                                        </div>
                                    </div>
                                    <div id="direccion" class='descripcion_bolsa'>
                                        <?php echo $vacante->descripcion; ?>

                                        <h3>Sueldo</h3>
                                        <p><?php echo $vacante->sueldo; ?></p>
                                    </div
                                </td>
                                <td bgcolor="#455560">
                                    <form class="forma3" method="POST" action="<?php echo e(route('enviar_correo_vacante')); ?>" enctype="multipart/form-data">
                                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                        <input type = 'hidden' name = 'nombreVacante' value = '<?php echo e($vacante->titulo); ?>'>
                                        <input type = 'hidden' name = 'empresaVacante' value = '<?php echo e($vacante->empresa); ?>'>
                                        <div class="form-group">
                                            <label for="nombre">Nombre</label>
                                            <input id='nombre' type="text" name='nombre' required="required"  class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="correo">Email</label>
                                            <input id='correo' type="text" name='correo' required="required"  class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="telefono">Telefono</label>
                                            <input id='telefono' type="text" name='telefono' required="required"  class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="comentarios">Comentarios</label>
                                            <input id='comentarios' type="text" name='comentarios' required="required"  class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="cv">Curriculum</label>
                                            <input id='cv' type="file" name='cv' required="required"  class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <button class = 'button-two_crear' type ='submit'> <span class="texto_blanco">Postularme</span></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>   
    </div> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>