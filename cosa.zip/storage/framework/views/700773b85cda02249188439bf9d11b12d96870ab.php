<?php $__env->startComponent('mail::message'); ?>
# Hola, tienes un **correo nuevo** de

<?php $__env->startComponent('mail::panel'); ?>

<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>