<?php $__env->startSection('content'); ?>


<section class="content">

    <div class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <div class="empresa">
                    <div id="paginacion"><?php echo $puestos->render(); ?> </div>
                    <form class = '' method = 'get' action = '<?php echo url("puesto"); ?>/create'>
                        
                          <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nuevo Puesto</span></button>
                        
                    </form>


                        <div class="col-md-12 col-centered">
                            <div class="table-responsive">
                                <table class='table table-striped' cellpadding="10">
                                    <thead>
                                        <tr>
                                            <td>TITULO</td>
                                            <td>BORRAR</td>
                                            <td>EDITAR</td>
                                            <td>INFO</td>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                    <td><?php echo $puesto->titulo; ?></td>
                                                    <td>
                                                        <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/puesto/<?php echo $puesto->id; ?>/deleteMsg" ><i class = 'material-icons'>Borrar</i></a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('puesto.edit', $puesto->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/puesto/<?php echo $puesto->id; ?>/edit'><i class = 'material-icons'>Editar</i></a>
                                                    </td>
                                                    <td>
                                                        <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/puesto/<?php echo $puesto->id; ?>'><i class = 'material-icons'>Info</i></a>
                                                    </td>

                                            </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tbody>
                                </table> 
                            </div>    
                        </div>
                    <?php echo e($puestos->render()); ?>

            </div> 
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>