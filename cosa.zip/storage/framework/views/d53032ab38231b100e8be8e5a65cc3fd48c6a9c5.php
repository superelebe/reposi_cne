<?php $__env->startSection('content'); ?>


    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-cal.png')); ?>" alt="">
            </div>
        </div>
    </div>
<div class="empresas">
    <div class="ocho80">
        <table width="882" style="margin:45px 0 -25px;">
            <thead>
                <tr>
                    <td>EVENTO</td>
                    <td> </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <div id="nombre"><?php echo $calendario->title; ?></div>
                        <div id="subarea"><?php echo $calendario->start->format('d \- F \- Y'); ?></div>
                        <div id="direccion" class='descripcion_bolsa'>
                            <p>Horarios: <?php echo $calendario->horarios; ?></p>
                            <p>Inversion: <?php echo $calendario->inversion; ?></p>
                            <?php echo $calendario->descripcion; ?>

                            <p>Lugar: <?php echo e($calendario->lugar); ?></p>
                        </div>
                    </td>
                    <td bgcolor="#455560">
                        <img class='largo_imagenes_cursos' src="<?php echo e(asset($calendario->imagen)); ?>" alt="">
                    </td>
                </tr>
            </tbody>
        </table>   
    </div> 
</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>