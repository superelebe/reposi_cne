<?php $__env->startSection('content'); ?>

<section class="contenedor">
    <section class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <div class="col-md-8 col-xs-12 col-centered">
                <form method = 'get' action = '<?php echo route("home"); ?>'>
                    <button class = 'btn btn-danger'>Regresar</button>
                </form>
            </div>
            <div class='titulo_seccion'>
                Editar Perfil
            </div class='titulo_seccion'>
        </div>
        <div class="col-xs-12 col-md-8 col-centered formularios">
            <form method = 'POST' action = '<?php echo url("usuarios"); ?>/<?php echo $usuario->
        id; ?>/update' enctype="multipart/form-data" > 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>        
        <div class="form-group">
            <label for="empresa">Empresa</label>
            <input id="empresa" name = "empresa" type="text" class="form-control" value="<?php echo $usuario->
            empresa; ?>">
        </div>
        <div class="form-group">
            <label for="representante">Representante</label>
            <input id="representante" name = "representante" type="text" class="form-control" value="<?php echo $usuario->
            representante; ?>"> 
        </div>
        <div class="form-group">
            <label for="direccion">Direccion</label>
            <input id="direccion" name = "direccion" type="text" class="form-control" value="<?php echo $usuario->
            direccion; ?>">
        </div>
        <div class="form-group">
            <label for="imagenes">Imagenes</label>
            <img src="<?php echo url($usuario->
                        imagenes); ?>" alt="">
            <input id="imagenes" name = "imagenes" type="file" class="form-control" value="<?php echo $usuario->
            imagenes; ?>"> 
        </div>
        <div class="form-group">
            <label for="rfc">RFC</label>
            <input id="rfc" name = "rfc" type="text" class="form-control" value="<?php echo $usuario->
            rfc; ?>"> 
        </div>

        <div class="form-group">
            <label for="ciudad_id">Ciudad</label>
            <select name="ciudad_id" class="form-control">
                <option value="<?php echo $usuario->ciudad_id; ?>" selected style="display:none"><?php echo e($usuario->ciudad->nombre); ?></option>
                <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ciudad->id); ?>"><?php echo e($ciudad->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="servicio_id">Servicio</label>
            <select name="servicio_id" class="form-control" id='cat'>
                <option value="<?php echo e($usuario->servicios->id); ?>" selected ><?php echo e($usuario->servicios->nombre); ?></option>
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($servico->id); ?>"><?php echo e($servico->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="subarea_id">Sub Area</label>
            <select name="subarea_id" class="form-control" id='subarea'>
                <option value="<?php echo e($usuario->subarea->id); ?>" selected ><?php echo e($usuario->subarea->nombre); ?></option>
            </select>
        </div>
        <div class='subservicios'>
            
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input id="email" name = "email" type="email" class="form-control" value="<?php echo e($usuario->email); ?>"> 
        </div>

        <div class="form-group">
            <label for="certificados">Certificados</label>
            <input id="certificados" name = "certificados" type="text" class="form-control" value="<?php echo e($usuario->certificados); ?>">
        </div>
        <div class="form-group">
            <label for="cvs">Curriculum Vitae</label>
            <input id="cvs" name = "cvs"  type="file" class="form-control" value="<?php echo e($usuario->cvs); ?>"> 
        </div>
        <div class="form-group">
            <label for="descripcion">descripcion</label>
            <input id="descripcion" name = "descripcion" type="text" class="form-control" value="<?php echo e($usuario->descripcion); ?>"> 
        </div>
        <button class='button-two_crear' type ='submit'> <span class="texto_blanco">Actualizar</span> </button>
    </form>
        </div>
    </section>
</section>
<script>
    $('#cat').on('change',function(e){
        var potato = e.target.value;
        
        console.log(potato);
        $.get('ajaxSubarea/'+ potato+'', function(data){
            $('#subarea').empty();
            $.each(data, function(index, subareaObj){
                $('#subarea').append('<option value="'+ subareaObj.id+'">'+ subareaObj.nombre +'</option>');
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>