<?php $__env->startSection('content'); ?>


<div class="contenedor">
    <div class="row row-centered">
        <div class="col-md-12 col-centered img_centrada">
            <img src="<?php echo e(asset('img/banner-404.png')); ?>" alt="">
        </div>
    </div>
    <div class="row row-centered">
        <div class="col-md-4 col-centered titulo_seccion">
            <div class="panel panel-default">
                <div class="panel-heading">404</div>
            </div>
            <div >
            	Sitio expirado
            </div>
        </div>
        <div class="col-md-4 col-centered titulo_seccion" >
        	<a href="<?php echo URL::previous(); ?>">Regresar</a>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>