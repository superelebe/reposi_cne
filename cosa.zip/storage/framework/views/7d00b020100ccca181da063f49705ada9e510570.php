<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Show event
    </h1>
    <br>
    <form method = 'get' action = '<?php echo url("event"); ?>'>
        <button class = 'btn btn-primary'>event Index</button>
    </form>
    <br>
    <table class = 'table table-bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>title : </i></b>
                </td>
                <td><?php echo $event->title; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>start : </i></b>
                </td>
                <td><?php echo $event->start; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>end : </i></b>
                </td>
                <td><?php echo $event->end; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>imagen : </i></b>
                </td>
                <td><?php echo $event->imagen; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>color : </i></b>
                </td>
                <td><?php echo $event->color; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>subtitulo : </i></b>
                </td>
                <td><?php echo $event->subtitulo; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>descripcion : </i></b>
                </td>
                <td><?php echo $event->descripcion; ?></td>
            </tr>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>