<?php $__env->startSection('content'); ?>
<div class="fondo_capacitacion">
	<div class="ocho80">
        <div class="row row-centered">
            <div class='col-sm-5 margen_350'>
                <div class="row">
                    <div class="col-sm-12">
                        <a href=""><img src="<?php echo e(asset('img/pdficon-dg1.jpg')); ?>" alt=""></a>
                    </div>
                    <div class="col-sm-12">
                        <a href=""><img src="<?php echo e(asset('img/pdficon-dg2.jpg')); ?>" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class='padding_100'>
                    <div class='row row-centered'>
                            <div class="col-sm-8 col-centered">
                                <div class='img_principal_curso'>
                                    <img class='imagen_al_100' src="<?php echo e(asset($elprimero->imagen)); ?>" alt="">
                                </div>
                            </div>
                            <div class="col-sm-4 col-centered">
                                <div class="alineado_izq">
                                    <div class='fecha_inicio margen_10 color_blanco'>
                                        <?php echo e($elprimero->start->format('d / m / y')); ?>

                                    </div>
                                    <div class='titulo_curso_inicio margen_10'> 
                                        <?php echo e($elprimero->title); ?>

                                    </div>
                                    <div class='margen_10'>
                                        <?php echo e(substr(strip_tags($elprimero->descripcion),0,100)); ?><?php echo e(strlen(strip_tags($elprimero->descripcion)) > 100 ? "...":""); ?>

                                    </div>
                                    <div class='fondo_verde_obs vermas_blanco alineado_centro'><a href="<?php echo e($elprimero->url); ?>">Ver Mas</a></div>                                    
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="row row-centered">
                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-6 col-sm-4 margen_30">
                            <div class='img_sec_curso'>
                                <img class='imagen_al_100' src="<?php echo e(asset($potato->imagen)); ?>" alt="">
                            </div>
                            <div class='alineado_izq'>
                                <div class='fecha_inicio margen_10'>
                                    <?php echo e($potato->start->format('d / m / y')); ?>

                                </div>
                                <div class='titulo_curso_inicio margen_10'>
                                    <?php echo e($potato->title); ?>

                                </div>
                                <div class='margen_10'>
                                    <?php echo e(substr(strip_tags($potato->descripcion),0,100)); ?><?php echo e(strlen(strip_tags($potato->descripcion)) > 100 ? "...":""); ?>

                                </div>
                                <a class='margen_10' href="<?php echo e($elprimero->url); ?>">
                                <div class='fondo_verde_obs vermas_blanco alineado_centro'>
                                    <div>Ver Mas</div>
                                </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
<!--         <div id="capaconten" class="limpiar clearfix">p
    <div id="pendondgray">
        <span><a href="descargas/formato_Inscripcion_cursos_software.xlsx"><img src="img/pdficon-dg.jpg" alt="pdf" /><p>Formato de Inscripción para cursos de software</p></a></span>
        <span><a href="descargas/formato_Inscripcion_cursos_generales.xlsx"><img src="img/pdficon-dg.jpg" alt="pdf" /><p>Formato de Inscripción para cursos generales</p></a></span>
    </div>
</div>
<div class="curso-columna-1">
    <div class="row row-centered">

    </div>

</div> -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>