    <script src="//cloud.tinymce.com/stable/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea',plugins: "lists" });</script>
<?php $__env->startSection('content'); ?>

<section class="contenedor">
    <section class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <form method = 'get' action = '<?php echo url("organigrama"); ?>'>
                <button class = 'btn btn-danger'>Ver organigrama</button>
            </form>
        </div>
        <div class="col-xs-12 col-md-8 col-centered">
            <div class='titulo_seccion'>
                Crear Organigrama
            </div class='titulo_seccion'>
        </div>
        <div class="col-xs-12 col-md-8 col-centered formularios">
            <form method = 'POST' action = '<?php echo url("organigrama"); ?>' enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input id="nombre" name = "nombre" type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label for="subtitulo">Puesto</label>
                    <select name="puesto_id" id="puesto">
                        <option value="" selected disabled >Selecciona un puesto</option>
                        <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($puesto->id); ?>"><?php echo e($puesto->titulo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="imagen">Fotografia</label>
                    <input id="imagen" name = "imagen" type="file" class="form-control">
                </div>
                <div class="sub-main_crear">
                  <button class="button-two_crear" type = 'submit'><span class="texto_blanco">Crear</span></button>
                </div>
            </form>
        </div>x

    </section>  
</section>

<script>
    $('#puesto').on('change',function(e){
        console.log(e.target.value)
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>