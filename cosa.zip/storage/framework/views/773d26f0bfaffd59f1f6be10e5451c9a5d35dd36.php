<?php $__env->startComponent('mail::message'); ?>
# Nueva solicitud para la vacante **<?php echo e($data['vacante']); ?>** de la empresa _<?php echo e($data['empresa']); ?>_

<?php $__env->startComponent('mail::panel'); ?>
	Perfil candidato:
	Nombre: <?php echo e($data['nombre']); ?>

	correo: <?php echo e($data['correo']); ?>

	Telefono: <?php echo e($data['telefono']); ?>


	Comentarios: <?php echo e($data['comentarios']); ?>

<?php echo $__env->renderComponent(); ?>

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
