<?php $__env->startComponent('mail::message'); ?>
# Hola **<?php echo e($data['nombre']); ?>** gracias por postularte a la vacante  **<?php echo e($data['vacante']); ?>** CNEC Guanajuato

<?php $__env->startComponent('mail::panel'); ?>
	Le enviaremos cualquier informacion relacionada a la vacante a 
	este correo:
	<?php echo e($data['correo']); ?>

<?php echo $__env->renderComponent(); ?>

Si tienes dudas, llamenos al **(477) 711 21 68** o 
escribanos al correo _informes@cnecgto.org_

Con gusto le atenderemos.

<?php $__env->startComponent('mail::button', ['url' => '/']); ?>
Ir a cnec gto
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
