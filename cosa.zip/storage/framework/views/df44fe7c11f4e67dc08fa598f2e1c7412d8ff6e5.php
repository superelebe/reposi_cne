<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Subareas Index
    </h1>
    <form class = 'col s3' method = 'get' action = '<?php echo url("subarea"); ?>/create'>
        <button class = 'btn btn-primary' type = 'submit'>Crear Nuevo Sub Area</button>
    </form>
    <br>
    <br>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>nombre</th>
            <th>servicio</th>

            <th>opciones</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo $subarea->nombre; ?></td>
                <td><?php echo $subarea->servicios->nombre; ?></td>
                <td>
                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/trabajo/<?php echo $subarea->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                    <a href="<?php echo e(route('bolsa_trabajo.edit', $subarea->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/trabajo/<?php echo $subarea->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/trabajo/<?php echo $subarea->id; ?>'><i class = 'material-icons'>info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <?php echo $subareas->render(); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>