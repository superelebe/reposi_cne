<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Event Index
    </h1>
    <form class = 'col s3' method = 'get' action = '<?php echo url("event"); ?>/create'>
        <button class = 'btn btn-primary' type = 'submit'>Create New event</button>
    </form>
    <br>
    <br>
    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>title</th>
            <th>start</th>
            <th>end</th>
            <th>imagen</th>
            <th>color</th>
            <th>subtitulo</th>
            <th>descripcion</th>
            <th>actions</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo $event->title; ?></td>
                <td><?php echo $event->start; ?></td>
                <td><?php echo $event->end; ?></td>
                <td><?php echo $event->imagen; ?></td>
                <td><?php echo $event->color; ?></td>
                <td><?php echo $event->subtitulo; ?></td>
                <td><?php echo $event->descripcion; ?></td>
                <td>
                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/event/<?php echo $event->id; ?>/deleteMsg" ><i class = 'material-icons'>delete</i></a>
                    <a href = '#' class = 'viewEdit btn btn-primary btn-xs' data-link = '/event/<?php echo $event->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/event/<?php echo $event->id; ?>'><i class = 'material-icons'>info</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <?php echo $events->render(); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>