<?php $__env->startSection('content'); ?>


	<div id="calendar">
		
	</div>


<script>
$(document).ready(function(){
		var something = <?php echo $items; ?>;
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			navLinks: true, // can click day/week names to navigate views
			editable: true,
			selectable: true, // allow "more" link when too many events
			selectHelper: true,
			select: function(start){
				start = moment(start.format());
			},
			navLinkDayClick: function(date, jsEvent) {
		        alert('day', date.format()); // date is a moment
		        console.log('coords', jsEvent.pageX, jsEvent.pageY);
		    },
			events: something
		});


});	
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>