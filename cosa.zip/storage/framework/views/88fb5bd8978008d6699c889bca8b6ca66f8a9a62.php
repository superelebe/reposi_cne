<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Editar organigrama
    </h1>
    <form method = 'get' action = '<?php echo url("organigrama"); ?>'>
        <button class = 'btn btn-danger'>article Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("organigrama"); ?>/<?php echo $organigrama->id; ?>/update' enctype="multipart/form-data"> 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="titulo">titulo</label>
            <input id="titulo" name = "nombre" type="text" class="form-control" value="<?php echo $organigrama->nombre; ?>"> 
        </div>
        <div class="form-group">
            <label for="subtitulo">Puesto</label>
            <select name="puesto_id" id="">
                <option value="<?php echo e($organigrama->puesto_id); ?>" selected ><?php echo e($organigrama->puesto->titulo); ?></option>
                <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($puesto->id); ?>"><?php echo e($puesto->titulo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="imagen">Fotografia</label>
            <input id="imagen" name = "imagen" type="file" class="form-control">
        </div>
        <button class = 'btn btn-primary' type ='submit'>Update</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>