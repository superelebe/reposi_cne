<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Edit event
    </h1>
    <form method = 'get' action = '<?php echo url("event"); ?>'>
        <button class = 'btn btn-danger'>event Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("event"); ?>/<?php echo $event->
        id; ?>/update' enctype="multipart/form-data" > 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="title">title</label>
            <input id="title" name = "title" type="text" class="form-control" value="<?php echo $event->
            title; ?>"> 
        </div>
        <div class="form-group">
            <label for="start">start</label>
            <input id="start" name = "start" type="text" class="form-control" value="<?php echo $event->
            start; ?>"> 
        </div>
        <div class="form-group">
            <label for="end">end</label>
            <input id="end" name = "end" type="text" class="form-control" value="<?php echo $event->
            end; ?>"> 
        </div>
        <div class="form-group">
            <label for="imagen">imagen</label>
            <img src="<?php echo url($event->
                        imagen); ?>" alt="">
            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $event->
            imagen; ?>"> 
        </div>
        <div class="form-group">
            <label for="color">Activo</label><br>
            <input type="radio" name="activo" value=1> Activo <br>
            <input type="radio" name="activo" value=0> Inactivo <br>
        </div>
        <div class="form-group">
            <label for="color">color</label>
            <input id="color" name = "color" type="text" class="form-control" value="<?php echo $event->
            color; ?>"> 
        </div>
        <div class="form-group">
            <label for="subtitulo">subtitulo</label>
            <input id="subtitulo" name = "subtitulo" type="text" class="form-control" value="<?php echo $event->
            subtitulo; ?>"> 
        </div>
        <div class="form-group">
            <label for="descripcion">descripcion</label>
            <input id="descripcion" name = "descripcion" type="text" class="form-control" value="<?php echo $event->
            descripcion; ?>"> 
        </div>
        <button class = 'btn btn-primary' type ='submit'>Update</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>