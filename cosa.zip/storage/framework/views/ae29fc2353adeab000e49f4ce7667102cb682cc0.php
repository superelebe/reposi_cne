<?php $__env->startComponent('mail::message'); ?>
# Gracias <?php echo e($user->empresa); ?> por registrarse a la CNEC Guanajuato

Gracias por suscribirte a nuestro **plan de afiliados**.

<?php $__env->startComponent('mail::panel'); ?>
	El correo con el que se registro es:
	<?php echo e($user->email); ?>

<?php echo $__env->renderComponent(); ?>

De momento estamos revisando la informacion enviada para darlo
de alta en nuestro sistema.

Te informaremos cuando tu cuenta sea dada de alta.

Si tienes dudas, llamenos al **(477) 711 21 68** o 
escribanos al correo _informes@cnecgto.org_

Con gusto le atenderemos.

<?php $__env->startComponent('mail::button', ['url' => '/']); ?>
Ir a cnec gto
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
