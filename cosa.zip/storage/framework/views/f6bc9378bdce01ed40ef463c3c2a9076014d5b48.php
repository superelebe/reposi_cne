<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Crear Noticia
    </h1>
    <form method = 'get' action = '<?php echo url("article"); ?>'>
        <button class = 'btn btn-danger'>Noticia Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("article"); ?>'>
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="titulo">Titulo</label>
            <input id="titulo" name = "titulo" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="subtitulo">Subtitulo</label>
            <input id="subtitulo" name= "subtitulo" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="cuerpo">Noticia</label>
            <textarea  id="cuerpo" name = "cuerpo" type="text" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen</label>
            <input id="imagen" name = "imagen" type="text" class="form-control">
        </div>
        <button class = 'btn btn-primary' type ='submit'>Crear</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>