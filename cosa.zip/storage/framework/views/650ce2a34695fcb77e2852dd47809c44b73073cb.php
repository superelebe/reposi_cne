    
<?php $__env->startSection('content'); ?>



<section class="content">

    <div class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <div id="trabajo">
                    <div id="selects"></div>
                    <div id="paginacion"><?php echo $dias->render(); ?> </div>
                    <form class = 'col s3' method = 'get' action = '<?php echo url("calendario"); ?>/create'>
                        <div class="sub-main">
                          <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nuevo Evento</span></button>
                        </div>
                    </form>


                        <div class="col-md-12 col-centered">
                            <div class="table-responsive">
                                <table class='table table-striped' cellpadding="10">
                                    <thead>
                                        <tr>
                                            <td>TITULO</td>
                                            <td>INICIO</td>
                                            <td>FINALIZA</td>
                                            <td>DESCRIPCIÓN</td>
                                            <td>SUELDO</td>
                                            <td>IMAGEN</td>
                                            <td>BORRAR</td>
                                            <td>EDITAR</td>
                                            <td>INFO</td>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                    <td><?php echo $evento->title; ?></td>
                                                    <td><?php echo $evento->start->format('d - m - Y'); ?></td>
                                                    <td><?php echo $evento->end->format('d - m - Y'); ?></td>
                                                    <td><?php echo e(substr(strip_tags($evento->descripcion),0,50)); ?><?php echo e(strlen(strip_tags($evento->descripcion)) > 50 ? "...":""); ?></td>
                                                    <td><?php echo $evento->sueldo; ?></td>
                                                    <td> <img class='largo_imagenes' src="<?php echo $evento->imagen; ?>" alt=""> </td>
                                                    <td>
                                                        <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/trabajo/<?php echo $evento->id; ?>/deleteMsg" ><i class = 'material-icons'>Borrar</i></a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('calendario.edit', $evento->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/calendario/<?php echo $evento->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                                                    </td>
                                                    <td>
                                                        <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/calendario/<?php echo $evento->id; ?>'><i class = 'material-icons'>info</i></a>
                                                    </td>

                                            </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tbody>
                                </table>    
                            </div>    
                        </div>
                    <?php echo e($dias->links()); ?>

            </div> 
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>