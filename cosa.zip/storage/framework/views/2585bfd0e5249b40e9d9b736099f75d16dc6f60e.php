<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Edit article
    </h1>
    <form method = 'get' action = '<?php echo url("puesto"); ?>'>
        <button class = 'btn btn-danger'>article Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("puesto"); ?>/<?php echo $puesto->id; ?>/update' enctype="multipart/form-data"> 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="titulo">titulo</label>
            <input id="titulo" name = "titulo" type="text" class="form-control" value="<?php echo $puesto->titulo; ?>"> 
        </div>
        <button class = 'btn btn-primary' type ='submit'>Update</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>