<?php $__env->startSection('content'); ?>
<div class="contenedor">
    <div class="row row-centered">
        <div class="col-md-12 col-centered img_centrada">
            <img src="<?php echo e(asset('img/banner-cal.png')); ?>" alt="">
        </div>
    </div>
    <div class="row row-centered">
        <div class="col-md-8 col-centered titulo_seccion">
            <div class="panel panel-default">
                <div class="panel-heading">ADMIN Dashboard</div>
            </div>
        </div>
    </div>

    <div class="row row-centered">
        <div class='col-xs-12 col-md-11 col-centered'>  
            <div class='caja_administrador caja_gris'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    NOTICIAS
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <?php echo e($noticia->titulo); ?> 
                            </div>
                            <div><?php echo e($noticia->created_at->format('d - M')); ?></div>
                            <div>
                                <a href="../article/<?php echo e($noticia->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('article.create')); ?>">Crear Noticia</a>
                </div>
            </div>
            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    VACANTES
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <?php echo e($vacante->titulo); ?> 
                            </div>
                            <div><?php echo e($vacante->created_at->format('d - M')); ?></div>
                            <div>
                                <a href="../bolsa_trabajo/<?php echo e($vacante->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('bolsa_trabajo.create')); ?>">Crear Vacantea</a>
                </div>
            </div>
            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    EVENTO
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <?php echo e($evento->title); ?> 
                            </div>
                            <div><?php echo e($evento->created_at->format('d - M')); ?></div>
                            <div>
                                <a href="../calendario/<?php echo e($evento->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('calendario.create')); ?>">Crear Evento</a>
                </div>
            </div>
            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    CAPACITACIÓN
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $capacitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <?php echo e($capacitacion->title); ?> 
                            </div>
                            <div>Inicio: <?php echo e($capacitacion->created_at->format('d - M')); ?></div>
                            <div>
                                <a href="../curso/<?php echo e($capacitacion->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('curso.create')); ?>">Crear Capacitación</a>
                </div>
            </div>

            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    BANNER
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <img src="<?php echo e($banner->title); ?> " alt="">
                            </div>
                            <div>
                                <a href="../banner/<?php echo e($banner->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('banner.create')); ?>">Crear Banner</a>
                </div>
            </div>

            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    ORGANIGRAMA
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $organigramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organigrama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <div>Nombre: <?php echo e($organigrama->nombre); ?></div>
                                <div>Puesto: <?php echo e($organigrama->puesto->titulo); ?></div>
                            </div>
                            <div>
                                <a href="../organigrama/<?php echo e($organigrama->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('organigrama.create')); ?>">Agregar al Organigrama</a>
                </div>
            </div>
            <div class='caja_administrador caja_verde'>
                <div class='crear_nuevo fondo_verde titulo_crear'>
                    PUESTO ORGANIGRAMA
                </div>
                <div class='padding_15'>
                    <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $superpuesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='crear_border_abajo'>
                            <div>
                                <div>Nombre: <?php echo e($superpuesto->titulo); ?></div>
                            </div>
                            <div>
                                <a href="../puesto/<?php echo e($superpuesto->id); ?>/edit"> EDITAR</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class='crear_nuevo fondo_verde'>
                   <a href="<?php echo e(route('puesto.create')); ?>">Agregar al Puesto Organigrama</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row row-centered">
        <div class="col-md-12">
            
        </div>
    </div>

    <div class="row row-centered">
            <div class='col-md-8 col-centered '>
                <div class='titulo_seccion'>Solicitudes para Afiliación</div>
                <div class='col-md-12 col-centered'>
                    <?php $__currentLoopData = $noAfiliados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noAfiliado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='col-md-12'>
                            <div class='empresas_afiliadas alineados_usuario'>
                                <?php echo e($noAfiliado->empresa); ?>

                                <a  class='alineado_derecha' href="<?php echo e(url('ver_usuario',$noAfiliado->id)); ?>"> Ver Perfil</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>