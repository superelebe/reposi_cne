<?php $__env->startSection('content'); ?>

<section class="contenedor">
    <section class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <form method = 'get' action = '<?php echo url("/"); ?>'>
                <button class = 'btn btn-danger'>Ver todos los cursos</button>
            </form>
        </div>
        <div class="col-md-8 col-xs-12 col-centered">
            <div class='titulo_seccion'>
                Crear Sub Area de Servicios
            </div class='titulo_seccion'>
        </div>
        <div class="col-xs-12 col-md-8 col-centered formularios">
            <form method = 'POST' action = '<?php echo url("subarea"); ?>' enctype="multipart/form-data">
                <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input id="nombre" name = "nombre" type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label for="subtitulo">Que tipo de servicio es?</label>
                    <select name="servicios" id="">
                    <option value="0">Elige un serivicio</option>
                        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($servicio->id); ?>"> <?php echo e($servicio->nombre); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button class = 'btn btn-primary' type ='submit'>Crear</button>
            </form>
        </div>

    </section>  
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>