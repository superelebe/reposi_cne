<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Editar Calendario
    </h1>
    <form method = 'get' action = '<?php echo url("calendario"); ?>'>
        <button class = 'btn btn-danger'>event Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("calendario"); ?>/<?php echo $dia->id; ?>/update' enctype="multipart/form-data" > 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="title">Titulo</label>
            <input id="title" name = "titulo" type="text" class="form-control" value="<?php echo $dia->
            titulo; ?>"> 
        </div>
        <div class="form-group">
            <label for="subtitulo">subtitulo</label>
            <input id="subtitulo" name = "subtitulo" type="text" class="form-control" value="<?php echo $dia->
            subtitulo; ?>"> 
        </div>
        <div class="form-group">
            <label for="start">start</label>
            <input id="start" name = "start" type="text" class="form-control" value="<?php echo $dia->
            start; ?>"> 
        </div>
        <div class="form-group">
            <label for="end">end</label>
            <input id="end" name = "end" type="text" class="form-control" value="<?php echo $dia->
            end; ?>"> 
        </div>
        <div class="form-group">
            <label for="imagen">imagen</label>
            <img src="<?php echo url($dia->
                        imagen); ?>" alt="">
            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $dia->
            imagen; ?>"> 
        </div>
        <div class="form-group">
            <label for="color">color</label>
            <input id="color" name = "color" type="text" class="form-control" value="<?php echo $dia->
            color; ?>"> 
        </div>
        <div class="form-group">
            <label for="descripcion">descripcion</label>
            <input id="descripcion" name = "descripcion" type="text" class="form-control" value="<?php echo $dia->
            descripcion; ?>"> 
        </div>
        <button class = 'btn btn-primary' type ='submit'>Actualizar</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>