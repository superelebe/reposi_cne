<?php $__env->startSection('content'); ?>

    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-vacantes.png')); ?>" alt="">
            </div>
        </div>
    </div>
    <section class="ocho80">
        <div class='contend'>
            <div class='row row-centered vacante '>
                    <?php $__currentLoopData = $vacante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class='col-xs-12 col-md-4 margin_30'>
                        <div>
                            <div class='subtitulo_seccion'><?php echo e($vacantes->titulo); ?></div>
                            <p><?php echo e($vacantes->empresa); ?></p>
                            <p><?php echo e(date("d M", strtotime($vacantes->start))); ?></p>
                            <p><?php echo e(substr(strip_tags($vacantes->descripcion),0,50)); ?><?php echo e(strlen(strip_tags($vacantes->descripcion)) > 50 ? "...":""); ?></p>
                        </div>
                        <div class='alineado_derecha'><a  href="/bolsa_trabajo_cnec/<?php echo e($vacantes->id); ?>">Ver mas</a></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>       
        </div>

    </section>
    <?php echo e($vacante->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>