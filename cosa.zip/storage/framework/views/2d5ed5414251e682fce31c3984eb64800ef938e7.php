<?php $__env->startSection('content'); ?>

<section class="content">

    <div class="simibanner">
    </div>

    <div class="notifoto"><img src="<?php echo url($article->imagen); ?>" alt="">
    </div>

    <div id="noti">
        <div class="ocho80">
            <div id="noticonten" class="limpiar">
                <h3><?php echo $article->titulo; ?></h3>
                <span></span>
                <p><?php echo $article->cuerpo; ?></p>
                <a href="javascript:history.go(-1)" name="Regresar al incio"><img src="<?php echo e(asset('img/btn-regresar.png')); ?>"  alt="regresar" /></a>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>