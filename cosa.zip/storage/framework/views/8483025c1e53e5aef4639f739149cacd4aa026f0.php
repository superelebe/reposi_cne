
<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        <?php echo e($article->titulo); ?>

    </h1>
    <table class = 'table table-bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    <b><i>titulo : </i></b>
                </td>
                <td><?php echo $article->titulo; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>subtitulo : </i></b>
                </td>
                <td><?php echo $article->subtitulo; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>cuerpo : </i></b>
                </td>
                <td><?php echo $article->cuerpo; ?></td>
            </tr>

            <tr>
                <td>
                    <b><i>Imagen : </i></b>
                </td>
                <td><?php echo $article->imagen; ?></td>
            </tr>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>