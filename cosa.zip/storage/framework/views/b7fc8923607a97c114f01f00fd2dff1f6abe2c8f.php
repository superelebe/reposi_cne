<?php $__env->startSection('content'); ?>


    <div class="contenedor">
        <div class="row row-centered">
            <div class="col-md-12 col-centered img_centrada">
                <img src="<?php echo e(asset('img/banner-vacante.png')); ?>" alt="">
            </div>
        </div>
    </div>



<section class="content">

    <div class="row row-centered">
        <div class="col-md-8 col-xs-12 col-centered">
            <div class="col-xs-12 col-centered">        
                <form  method = 'get' action = '<?php echo e(url("article")); ?>/create'>
                      <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nueva noticia</span></button>
                </form>
                
            </div>

            <div id="paginacion"><?php echo e($articles->links()); ?> </div>
              <div class="col-md-12 col-centered">
                <div class="table-responsive">
                    <table class='table table-striped' cellpadding="10">
                        <thead>
                            <tr>
                                <td>TITULO</td>
                                <td>SUBTITULO</td>
                                <td>IMAGEN</td>
                                <td>BORRAR</td>
                                <td>EDITAR</td>
                                <td>INFO</td>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                <td><?php echo e($article->titulo); ?></td>
                                <td><?php echo e($article->subtitulo); ?></td>
                                <td><?php echo e(substr(strip_tags($article->cuerpo),0,50)); ?><?php echo e(strlen(strip_tags($article->cuerpo)) > 50 ? "...":""); ?></td>
                                <td><img class='largo_imagenes' src="<?php echo e(url($article->imagen)); ?>" alt=""></td>
                                <td>
                                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/article/<?php echo e($article->id); ?>/deleteMsg" ><i class = 'material-icons'>Borrar</i></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('article.edit', $article->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/article/<?php echo e($article->id); ?>/edit'><i class = 'material-icons'>edit</i></a>
                                </td>
                                <td>
                                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/article/<?php echo e($article->id); ?>'><i class = 'material-icons'>info</i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>    
                </div>    
            </div>
            <?php echo e($articles->links()); ?>

        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>