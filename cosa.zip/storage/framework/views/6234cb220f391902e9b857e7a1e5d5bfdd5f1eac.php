<?php $__env->startSection('content'); ?>

<section class="content">
    <div id="notilist" class="limpiar clearfix"> 
        <div class="ocho80">
            <div id="notilistconten">
                <table cellspacing="0" cellpadding="3" width="777" border="0">
                    <tbody>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $noticia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <div class="noticia">
                                        <h3><?php echo e($noticias->titulo); ?></h3>
                                        <span><?php echo e($noticias->created_at->toFormattedDateString()); ?></span>
                                        <div class="con_img_noti">
                                            <img src="<?php echo e(($noticias->imagen)); ?>" alt="">
                                        </div>
                                        <p><?php echo e(substr(strip_tags($noticias->cuerpo),0,100)); ?><?php echo e(strlen(strip_tags($noticias->cuerpo)) > 100 ? "...":""); ?></p>
                                        <a href="/noticia/<?php echo e($noticias->id); ?>">Ver mas</a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo e($noticia->links()); ?>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>