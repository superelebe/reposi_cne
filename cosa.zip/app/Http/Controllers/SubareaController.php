<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;
use App\Subarea;

class SubareaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subareas = Subarea::paginate(6);
        return view('subarea.index',compact('subareas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create - Subarea';
        $servicios = Service::all();
        
        return view('subarea.create', compact('servicios'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $subarea = new Subarea();
        
        $subarea->nombre = $request->nombre;
        
        $subarea->servicios_id = $request->servicios;

        
        
        $subarea->save();

        return redirect('subarea');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function obtenerSuabreas(Request $request, $id){
        if($request->ajax()){
            $subarea = Subarea::obtenerSuabreasRegistro($id);
            return response()->json($subarea);
        }
    }
}
