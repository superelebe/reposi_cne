Gracias {{ $empresa }} por registrarse a la CNEC Guanajuato

Gracias por suscribirte a nuestro **plan de afiliados**.

	<p>De click en el link para tener acceso:</p>
	<a href="{{route('verificacion',$email_token)}}"> Link</a>

<p>De momento estamos revisando la informacion enviada para darlo
de alta en nuestro sistema</p>.

<p>Te informaremos cuando tu cuenta sea dada de alta.</p>

<p>Si tienes dudas, llamenos al (477) 711 21 68 o 
escribanos al correo informes@cnecgto.org</p>

<p>Con gusto le atenderemos.</p>